// CONSULTAR EL TIEMPO MEDIANTE LA API OPENWEATHER
const climaDiv = document.getElementById("clima");

if(climaDiv){

fetch("https://api.openweathermap.org/data/2.5/weather?q=Madrid&appid=931863481b04894fdc5cded174353014&units=metric&lang=es")

.then(response => response.json())

.then(data => {

let temperatura = data.main.temp;

let clima = data.weather[0].main;

let mensaje = "";

if(clima == "Rain"){

mensaje = "Hay previsión de lluvia para la reserva.";

}
else if(clima == "Clear"){

mensaje = "Tiempo despejado para jugar.";

}
else if(clima == "Clouds"){

mensaje = "Cielo nublado.";

}
else{

mensaje = "Tiempo variable.";

}

climaDiv.innerHTML =
mensaje + "<br>Temperatura actual: " + temperatura + "°C";

})

.catch(error => {

climaDiv.innerHTML =
"No se pudo cargar el tiempo.";

});

}

// VALIDAR NÚMERO DE TARJETA
const tarjeta = document.querySelector('input[placeholder="1234 5678 9012 3456"]');

if(tarjeta){

tarjeta.addEventListener("input", function () {

this.value = this.value.replace(/[^0-9 ]/g,'');

if(this.value.length > 19){

this.value = this.value.substring(0,19);

}

});

}

// VALIDAR CVV
const cvv = document.querySelector('input[placeholder="123"]');

if(cvv){

cvv.addEventListener("input", function () {

this.value = this.value.replace(/[^0-9]/g, '');

});

}

// VALIDAR NOMBRE DEL TITULAR
const titular = document.querySelector('input[placeholder="Nombre del titular"]');

if(titular){

titular.addEventListener("input", function () {

this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g,'');

if(this.value.length > 50){

this.value = this.value.substring(0,50);

}

});

}

// VALIDAR CADUCIDAD
const caducidad = document.getElementById("caducidad");

if(caducidad){

caducidad.addEventListener("input", function () {

let valor = this.value.replace(/\D/g, '');

if(valor.length > 4){

valor = valor.substring(0,4);

}

if(valor.length >= 3){

valor = valor.substring(0,2) + "/" + valor.substring(2);

}

this.value = valor;

});

caducidad.addEventListener("blur", function () {

const valor = this.value;

if(valor.length === 5){

const partes = valor.split("/");

const mes = parseInt(partes[0]);

const anio = parseInt(partes[1]);

const fechaActual = new Date();

const anioActual = fechaActual.getFullYear() % 100;

const mesActual = fechaActual.getMonth() + 1;

if(

mes < 1 ||
mes > 12 ||
anio < anioActual ||
(anio == anioActual && mes < mesActual)

){

this.classList.add("is-invalid");

this.value = "";
}

}

});

}

// CONFIRMAR CANCELACIÓN DE RESERVA

function confirmarCancelacion(event,url){

event.preventDefault();

Swal.fire({

title:'¿Cancelar reserva?',
text:'Esta acción cancelará la reserva',
icon:'warning',
showCancelButton:true,
confirmButtonText:'Sí, cancelar',
cancelButtonText:'No'

}).then((result)=>{

if(result.isConfirmed){

window.location.href = url;

}

});

}

// CONFIRMAR DESACTIVACIÓN DE USUARIO
function confirmarDesactivacion(event,url){

event.preventDefault();

Swal.fire({

title:'¿Desactivar usuario?',
text:'El usuario no podrá iniciar sesión',
icon:'warning',
showCancelButton:true,
confirmButtonText:'Sí, desactivar',
cancelButtonText:'Cancelar'

}).then((result)=>{

if(result.isConfirmed){

window.location.href = url;

}

});

return false;

}

// CONFIRMAR ACTIVACIÓN

function confirmarActivacion(event,url){

event.preventDefault();

Swal.fire({

title:'¿Activar usuario?',
text:'El usuario podrá iniciar sesión otra vez',
icon:'question',
showCancelButton:true,
confirmButtonText:'Sí, activar',
cancelButtonText:'Cancelar'

}).then((result)=>{

if(result.isConfirmed){

window.location.href = url;

}

});

return false;

}

// CONFIRMAR ELIMINACIÓN DE PISTA
function confirmarEliminarPista(event,url){

event.preventDefault();

Swal.fire({

title:'¿Eliminar pista?',
text:'Esta acción no se puede deshacer',
icon:'warning',
showCancelButton:true,
confirmButtonText:'Sí, eliminar',
cancelButtonText:'Cancelar'

}).then((result)=>{

if(result.isConfirmed){

window.location.href = url;

}

});

return false;

}

// CONFIRMAR ELIMINACIÓN DE COMENTARIO
function confirmarEliminarComent(event,url){

event.preventDefault();

Swal.fire({

title:'¿Eliminar Comentario?',
text:'Esta acción no se puede deshacer',
icon:'warning',
showCancelButton:true,
confirmButtonText:'Sí, eliminar',
cancelButtonText:'Cancelar'

}).then((result)=>{

if(result.isConfirmed){

window.location.href = url;

}

});

return false;

}