<?php
session_start();

include("conexion.php");
global $conexion;

/* Comprobar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* Obtener el número total de usuarios registrados */
require_once "models/Usuario.php";

$usuarioModel = new Usuario();

$totalUsuarios = $usuarioModel->contarUsuarios();

/* Obtener el número total de reservas */
require_once "models/Reserva.php";

$reservaModel = new Reserva();

$totalReservas = $reservaModel->contarReservas();

/* Obtener el número total de pistas deportivas */
require_once "models/Pista.php";

$pistaModel = new Pista();

$totalPistas = $pistaModel->contarPistas();

/* Contar incidencias pendientes de revisión */
$sqlIncidencias = "SELECT COUNT(*) AS total
                   FROM incidencia
                   WHERE estado='pendiente'";

$resultadoIncidencias = mysqli_query($conexion,$sqlIncidencias);

$totalIncidencias = mysqli_fetch_assoc($resultadoIncidencias)['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Panel administrador | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="admin.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_comentarios.php">
Comentarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-3">
Panel de administrador
</h1>

<p class="text-center text-muted mb-5">
Desde aquí podrás gestionar usuarios, reservas, pistas y comentarios.
</p>

<!-- TARJETAS DE ESTADÍSTICAS -->
<div class="row g-4 mb-5 mt-2">

<div class="col-md-3">

<div class="card shadow border-0 text-center h-100">

<div class="card-body">

<h2 class="fw-bold text-primary">
<?php echo $totalUsuarios; ?>
</h2>

<p class="mb-0">
Usuarios
</p>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center h-100">

<div class="card-body">

<h2 class="fw-bold text-success">
<?php echo $totalReservas; ?>
</h2>

<p class="mb-0">
Reservas
</p>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center h-100">

<div class="card-body">

<h2 class="fw-bold text-warning">
<?php echo $totalIncidencias; ?>
</h2>

<p class="mb-0">
Incidencias
</p>

</div>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center h-100">

<div class="card-body">

<h2 class="fw-bold text-danger">
<?php echo $totalPistas; ?>
</h2>

<p class="mb-0">
Pistas
</p>

</div>

</div>

</div>

</div>

<!-- ACCESOS A LOS MÓDULOS DE ADMINISTRACIÓN -->
<div class="row g-4">

<div class="col-md-3">

<div class="card shadow border-0 text-center p-4 h-100">

<h3 class="mb-3">
Reservas
</h3>

<p class="text-muted">
Gestionar reservas de usuarios.
</p>

<a href="admin_reservas.php" class="btn btn-dark mt-3">
Ver reservas
</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center p-4 h-100">

<h3 class="mb-3">
Pistas
</h3>

<p class="text-muted">
Administrar pistas deportivas.
</p>

<a href="admin_pistas.php" class="btn btn-dark mt-3">
Gestionar pistas
</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center p-4 h-100">

<h3 class="mb-3">
Usuarios
</h3>

<p class="text-muted">
Consultar usuarios registrados.
</p>

<a href="admin_usuarios.php" class="btn btn-dark mt-3">
Ver usuarios
</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center p-4 h-100">

<h3 class="mb-3">
Comentarios
</h3>

<p class="text-muted">
Gestionar comentarios y valoraciones.
</p>

<a href="admin_comentarios.php" class="btn btn-dark mt-3">
Ver comentarios
</a>

</div>

</div>

<div class="col-md-3">

<div class="card shadow border-0 text-center p-4 h-100">

<h3 class="mb-3">
Incidencias
</h3>

<p class="text-muted">
Gestionar incidencias de usuarios.
</p>

<a href="admin_incidencias.php"
class="btn btn-dark mt-3">

Ver incidencias

</a>

</div>

</div>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>