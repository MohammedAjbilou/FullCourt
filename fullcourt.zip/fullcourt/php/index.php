<?php

/* Conexión con la base de datos */
include("conexion.php");

global $conexion;

/* Iniciar sesión */
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FullCourt – Reserva de pistas deportivas</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="../css/style.css">

</head>

<body style="background:#f4f7f5;">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">
<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">
<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">
FullCourt
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto">

<?php if(isset($_SESSION['usuario'])){ ?>

<li class="nav-item">
<a class="nav-link active fw-bold" href="index.php">
Inicio
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="perfil.php">Perfil</a>
</li>

<li class="nav-item">
<a class="nav-link " href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_incidencias.php">
Incidencias
</a>
</li>

<?php }else{ ?>

<li class="nav-item">
<a class="nav-link" href="login.php">Login</a>
</li>

<li class="nav-item">
<a class="nav-link" href="registro.php">Registro</a>
</li>

<?php } ?>

<li class="nav-item">
<a class="nav-link" href="mis_favoritos.php">
Favoritos
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">Cerrar sesión</a>
</li>

</ul>
</div>

</div>
</nav>

<!-- HERO -->
<section class="container-fluid p-0">
<div id="carouselExample" class="carousel slide" data-bs-ride="carousel">

<div class="carousel-inner">

<div class="carousel-item active">
<img src="../icons/hero.jpg" class="d-block w-100" alt="Fútbol">
</div>

<div class="carousel-item">
<img src="../icons/hero22.webp" class="d-block w-100" alt="Baloncesto">
</div>

<div class="carousel-item">
<img src="../icons/hero333.jpg" class="d-block w-100" alt="Pádel">
</div>

</div>

<button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
<span class="carousel-control-prev-icon"></span>
</button>

<button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
<span class="carousel-control-next-icon"></span>
</button>

</div>
</section>

<!-- INTRO -->
<section class="container text-center py-5">
<h1 class="fw-bold mb-3" style="color:#14532d;">Reserva tu pista en segundos</h1>
<p class="lead text-secondary">
Elige tu deporte favorito y asegura tu pista de forma rápida y sencilla.
</p>
</section>

<!-- Mostrar mensaje al añadir una pista a favoritos -->
<?php if(isset($_GET['favorito'])){ ?>

<div class="container mt-4">

<div class="alert alert-success text-center shadow">
 Pista añadida a favoritos correctamente</div>

</div>

<?php } ?>

<!-- Deportes disponibles para reserva -->
<section class="container pb-5">
<div class="row g-4">

<!-- FUTBOL -->
<div class="col-md-4">

<div class="card h-100 shadow border-0">

<img src="../icons/futbol.svg" class="card-img-top" alt="Fútbol">

<div class="card-body text-center">

<h3>Fútbol</h3>

<?php

/* Obtener valoración media de la pista de fútbol */
$sqlMedia1 = "SELECT AVG(valoracion) AS media 
              FROM comenta
              WHERE id_pista=1";

$resultadoMedia1 = mysqli_query($conexion, $sqlMedia1);

$media1 = mysqli_fetch_assoc($resultadoMedia1);

?>

<?php
/* Redondear valoración para mostrar estrellas */
$nota1 = round($media1['media']);
?>

<div class="mb-2">

<?php for($i=1; $i<=5; $i++){ ?>

    <?php if($i <= $nota1){ ?>

        <i class="bi bi-star-fill text-warning"></i>

    <?php }else{ ?>

        <i class="bi bi-star text-secondary"></i>

    <?php } ?>

<?php } ?>

</div>

<p>Pistas de fútbol 7.</p>

<div class="d-flex gap-2 justify-content-center mb-3">

<a href="reservas.php?deporte=futbol"
class="btn btn-success w-100">
Reservar
</a>

<a href="favorito.php?id_pista=1" class="btn btn-outline-danger w-100">
Favorito
</a>

</div>

<div class="d-flex justify-content-center gap-3">

<a href="comentario.php?id_pista=1" class="text-decoration-none">
Comentar
</a>

<a href="ver_comentarios.php?id_pista=1" class="text-decoration-none">
Ver comentarios
</a>

</div>

</div>
</div>
</div>

<!-- BALONCESTO -->
<div class="col-md-4">

<div class="card h-100 shadow border-0">

<img src="../icons/bbb.jpg" class="card-img-top" alt="Baloncesto">

<div class="card-body text-center">

<h3>Baloncesto</h3>

<?php

/* Obtener valoración media de la pista de baloncesto */
$sqlMedia2 = "SELECT AVG(valoracion) AS media 
              FROM comenta
              WHERE id_pista=2";

$resultadoMedia2 = mysqli_query($conexion, $sqlMedia2);

$media2 = mysqli_fetch_assoc($resultadoMedia2);

?>

<?php
$nota2 = round($media2['media']);
?>

<div class="mb-2">

<?php for($i=1; $i<=5; $i++){ ?>

    <?php if($i <= $nota2){ ?>

        <i class="bi bi-star-fill text-warning"></i>

    <?php }else{ ?>

        <i class="bi bi-star text-secondary"></i>

    <?php } ?>

<?php } ?>

</div>

<p>Pistas cubiertas y exteriores.</p>

<div class="d-flex gap-2 justify-content-center mb-3">

<a href="reservas.php?deporte=baloncesto"
class="btn btn-success w-100">
Reservar
</a>
<a href="favorito.php?id_pista=2" class="btn btn-outline-danger w-100">
Favorito
</a>

</div>

<div class="d-flex justify-content-center gap-3">

<a href="comentario.php?id_pista=2" class="text-decoration-none">
Comentar
</a>

<a href="ver_comentarios.php?id_pista=2" class="text-decoration-none">
Ver comentarios
</a>

</div>

</div>
</div>
</div>

<!-- PADEL -->
<div class="col-md-4">

<div class="card h-100 shadow border-0">

<img src="../icons/padel.jpg" class="card-img-top" alt="Pádel">

<div class="card-body text-center">

<h3>Pádel</h3>

<?php

/* Obtener valoración media de la pista de pádel */
$sqlMedia3 = "SELECT AVG(valoracion) AS media 
             FROM comenta
              WHERE id_pista=3";

$resultadoMedia3 = mysqli_query($conexion, $sqlMedia3);

$media3 = mysqli_fetch_assoc($resultadoMedia3);

?>

<p class="text-warning fs-5 mb-1">

<?php if($media3['media'] != null){ ?>

<?php
$nota3 = round($media3['media']);
?>

<div class="mb-2">

<?php for($i=1; $i<=5; $i++){ ?>

    <?php if($i <= $nota3){ ?>

        <i class="bi bi-star-fill text-warning"></i>

    <?php }else{ ?>

        <i class="bi bi-star text-secondary"></i>

    <?php } ?>

<?php } ?>

</div>

<?php }else{ ?>

<p class="text-muted mb-1">
Sin valoraciones
</p>

<?php } ?>

</p>

<p>Pistas modernas iluminadas.</p>

<div class="d-flex gap-2 justify-content-center mb-3">

<a href="reservas.php?deporte=padel"
class="btn btn-success w-100">
Reservar
</a>

<a href="favorito.php?id_pista=3" class="btn btn-outline-danger w-100">
Favorito
</a>

</div>

<div class="d-flex justify-content-center gap-3">

<a href="comentario.php?id_pista=3" class="text-decoration-none">
Comentar
</a>

<a href="ver_comentarios.php?id_pista=3" class="text-decoration-none">
Ver comentarios
</a>

</div>

</div>
</div>
</div>

</div>
</section>

<!-- Sección informativa sobre la empresa -->
<section class="bg-white py-5">
<div class="container">

<h2 class="text-center mb-4" style="color:#14532d;">¿Quiénes somos?</h2>

<p class="text-center text-muted mb-5">
Somos una plataforma digital especializada en la reserva rápida y sencilla de instalaciones deportivas.
 Nuestro objetivo es facilitar el acceso al deporte mediante un sistema intuitivo, accesible y disponible desde cualquier dispositivo.
</p>

<div class="row g-4">

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Instalaciones modernas</h4>
<p>
    Contamos con pistas renovadas y equipadas con materiales de calidad,
    diseñadas para ofrecer la mejor experiencia deportiva a nuestros usuarios.
</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Reserva inmediata</h4>
<p>
     Consulta la disponibilidad en tiempo real y confirma tu reserva en pocos pasos,
    sin complicaciones ni esperas innecesarias.
</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Atención personalizada</h4>
<p>
    Ofrecemos soporte continuo para garantizar una experiencia segura,
    eficiente y adaptada a las necesidades de cada usuario.
</p>
</div>
</div>
</div>

</div>
</div>
</section>

<!-- Próximos proyectos y ampliaciones -->
<section class="container py-5">

<h2 class="text-center mb-4" style="color:#14532d;">Nuevos proyectos</h2>

<p class="text-center text-muted mb-5">
En FullCourt seguimos ampliando nuestras instalaciones para ofrecer nuevas
 experiencias deportivas y mejorar nuestros servicios.
</p>

<div class="row g-5">

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Pista de fútbol sala</h4>
<p>Próxima apertura de una pista cubierta adaptada para entrenamientos y competiciones.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Nuevas pistas de pádel</h4>
 <p>Ampliación de nuestras instalaciones con pistas modernas e iluminación mejorada.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card h-100 shadow-sm border-0">
<div class="card-body">
<h4>Zona de entrenamiento</h4>
<p>Espacio dedicado a la preparación física y entrenamiento funcional.</p>
</div>
</div>
</div>

</div>
</section>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
