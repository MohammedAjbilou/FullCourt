<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

/* Cargar librería PHPMailer */
require '../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
global $conexion;

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
}

/* Obtener los datos de la reserva seleccionada */
$id_reserva = $_GET['id_reserva'];

/* Consultar información de la reserva y de la pista */
$sqlReserva = "SELECT reserva.*, pista.nombre, pista.precio_hora
               FROM reserva
               INNER JOIN pista
               ON reserva.id_pista = pista.id_pista
               WHERE reserva.id_reserva='$id_reserva'";

$resultadoReserva = mysqli_query($conexion, $sqlReserva);

$reserva = mysqli_fetch_assoc($resultadoReserva);

/* Procesar el pago de la reserva */
if(isset($_POST['pagar'])){

    $metodo_pago = "Tarjeta";

    $fecha_pago = date("Y-m-d");

    /* Obtener los datos del usuario para enviar el correo */

    $usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

$importe = $reserva['precio_hora'];

    /* Registrar el pago en la base de datos */
$sqlPago = "INSERT INTO pago
            (importe,fecha_pago,metodo_pago,id_usuario,id_reserva)
            VALUES
            ('$importe','$fecha_pago','$metodo_pago','$id_usuario','$id_reserva')";

    mysqli_query($conexion, $sqlPago);

    /* Actualizar el estado de la reserva a pagada */
        $sqlActualizar = "UPDATE reserva
                      SET estado='pagada'
                      WHERE id_reserva='$id_reserva'";

    mysqli_query($conexion, $sqlActualizar);

/* Configurar el correo de confirmación */
$mail = new PHPMailer(true);

try {

    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';

    $mail->SMTPAuth = true;

    $mail->Username = 'fullcourtbooking@gmail.com';

    $mail->Password = 'soln ywnm mypb uwdz';

    $mail->SMTPSecure = 'tls';

    $mail->Port = 587;

    $mail->setFrom('fullcourtbooking@gmail.com', 'FullCourt');

    $mail->addAddress($usuario['email']);

    $mail->isHTML(true);

    $mail->Subject = 'Reserva pagada correctamente';

    $mail->Body = "
    <h2>Pago confirmado</h2>

    <p>Tu reserva ha sido pagada correctamente.</p>

    <p><strong>Pista:</strong> ".$reserva['nombre']."</p>

    <p><strong>Fecha:</strong> ".$reserva['fecha']."</p>

    <p><strong>Hora:</strong> ".$reserva['hora']."</p>

    <p><strong>Total:</strong> ".$reserva['precio_hora']."€</p>

    <br>

    <p>Gracias por confiar en FullCourt.</p>
    ";

    /* Enviar comprobante de pago al usuario */
     $mail->send();

     /* Ignorar errores de correo para no bloquear el pago */
} catch (Exception $e) {

}

    header("Location: mis_reservas.php?pago=ok");

    exit();
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Pago | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../styles.css">

</head>

<body style="background:#f4f7f5;">

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-lg-10">

<div class="card shadow border-0 rounded-4 overflow-hidden">

<div class="row g-0">

<!-- RESUMEN -->
<div class="col-md-5 text-white p-5"
style="background:#14532d;">

<h2 class="fw-bold mb-4">
Resumen
</h2>

<hr>

<p class="mb-4">

<strong>Pista:</strong><br>
<?php echo $reserva['nombre']; ?>

</p>

<p class="mb-4">

<strong>Fecha:</strong><br>
<?php echo $reserva['fecha']; ?>

</p>

<p class="mb-4">

<strong>Hora:</strong><br>
<?php echo $reserva['hora']; ?>

</p>

<hr>

<h3 class="fw-bold">
Total: <?php echo $reserva['precio_hora']; ?>€
</h3>

</div>

<!-- FORMULARIO -->
<div class="col-md-7 bg-white p-5">

<h1 class="fw-bold mb-4">
Finalizar pago
</h1>

<div class="d-flex align-items-center gap-3 mb-4">

<img
src="../icons/visa.svg"
style="width:70px; height:auto;">

<img
src="../icons/MasterCard_Logo.svg.png"
style="width:70px; height:auto;">

</div>

<form method="POST" autocomplete="off">

<div class="mb-3">

<label class="form-label">
Titular de la tarjeta
</label>

<input
type="text"
class="form-control form-control-lg"
placeholder="Nombre del titular"
pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ ]+"
title="Solo letras"
autocomplete="off"
required>

</div>

<div class="mb-3">

<label class="form-label">
Número de tarjeta
</label>

<input
type="text"
class="form-control form-control-lg"
placeholder="1234 5678 9012 3456"
maxlength="19"
pattern="[0-9 ]{16,19}"
title="Introduce 16 números"
inputmode="numeric"
autocomplete="off"
required>
</div>

<div class="row">

<div class="col-md-6 mb-3">

<label class="form-label">
Caducidad
</label>

<input
id="caducidad"
type="text"
class="form-control form-control-lg"
placeholder="MM/AA"
maxlength="5"
pattern="(0[1-9]|1[0-2])\/[0-9]{2}"
title="Introduce una fecha válida MM/AA"
autocomplete="off"
required>

<div class="invalid-feedback">
La tarjeta está caducada o la fecha no es válida
</div>

</div>

<div class="col-md-6 mb-3">

<label class="form-label">
CVV
</label>

<input
type="password"
class="form-control form-control-lg"
placeholder="123"
maxlength="3"
pattern="[0-9]{3}"
title="El CVV debe tener 3 números"
inputmode="numeric"
autocomplete="new-password"
required>
</div>

</div>

<button
type="submit"
name="pagar"
class="btn btn-success btn-lg w-100">

Pagar con tarjeta · <?php echo $reserva['precio_hora']; ?>€

</button>

</form>

</div>

</div>

</div>

</div>

</div>

</div>
<script src="../js/script.js"></script>
</body>
</html>