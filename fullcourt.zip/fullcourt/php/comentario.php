<?php
session_start();

include("conexion.php");
require_once "models/Usuario.php";
global $conexion;

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener el identificador de la pista seleccionada */
$id_pista = $_GET['id_pista'];

/* Registrar un nuevo comentario */
if(isset($_POST['comentar'])){

    $texto = $_POST['texto'];
    $valoracion = $_POST['valoracion'];

    /* Obtener los datos del usuario actual */
    $usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

    $fecha = date("Y-m-d");

    /* Insertar comentario y valoración en la base de datos */
   $sqlComentario = "INSERT INTO comenta
                  (texto,fecha,valoracion,id_usuario,id_pista)
                  VALUES
                  ('$texto','$fecha','$valoracion','$id_usuario','$id_pista')";

mysqli_query($conexion,$sqlComentario);
  
/* Volver a la página principal tras publicar el comentario */
    header("Location: index.php?comentario=ok");
exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Comentario | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">
    
<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a class="nav-link active fw-bold" href="perfil.php">
Perfil
</a>

</li>

<li class="nav-item">

<a class="nav-link" href="index.php">
Inicio
</a>

</li>

</ul>

</div>

</div>

</nav>

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-md-7">

<div class="card shadow border-0">

<div class="card-body p-5">

<h1 class="text-center mb-4">
Escribir comentario
</h1>

<form method="POST">

<div class="mb-4">

<label class="form-label">
Valoración
</label>

<select name="valoracion" class="form-select" required>

<option value="5">⭐⭐⭐⭐⭐</option>
<option value="4">⭐⭐⭐⭐</option>
<option value="3">⭐⭐⭐</option>
<option value="2">⭐⭐</option>
<option value="1">⭐</option>

</select>

</div>

<div class="mb-4">

<label class="form-label">
Comentario
</label>

<textarea
name="texto"
class="form-control"
rows="5"
required></textarea>

</div>

<div class="d-grid">

<button type="submit" name="comentar" class="btn btn-success btn-lg">

Publicar comentario

</button>

</div>

</form>

<div class="text-center mt-5">

<a href="index.php" class="btn btn-dark">
Volver
</a>

</div>

</div>

</div>

</div>

</div>

</div>
<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

</body>
</html>