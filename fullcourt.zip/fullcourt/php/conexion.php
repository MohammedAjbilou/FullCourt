<?php

/* Cargar la clase encargada de la conexión */
require_once "config/Database.php";

/* Crear objeto de conexión */
$database = new Database();

/* Conectar con la base de datos */
$conexion = $database->conectar();

/* Verificar que la conexión se ha realizado correctamente */
if (!$conexion) {
    die("Error de conexión");
}

?>