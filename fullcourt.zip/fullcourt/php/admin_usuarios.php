<?php
session_start();

include("conexion.php");
global $conexion;

/* Comprobar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* Desactivar la cuenta de un usuario */
if(isset($_GET['desactivar'])){

    $id = $_GET['desactivar'];

    mysqli_query($conexion,
    "UPDATE usuario
     SET estado='desactivado'
     WHERE id_usuario='$id'");

    header("Location: admin_usuarios.php");
    exit();
}

/* Reactivar la cuenta de un usuario */
if(isset($_GET['activar'])){

    $id = $_GET['activar'];

    mysqli_query($conexion,
    "UPDATE usuario
     SET estado='activo'
     WHERE id_usuario='$id'");

    header("Location: admin_usuarios.php");
    exit();
}

/* Obtener todos los usuarios registrados */
$sql = "SELECT * FROM usuario";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Gestión de usuarios | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="admin.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_comentarios.php">
Comentarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-3">
Gestión de usuarios
</h1>

<p class="text-center text-muted mb-5">
Consulta y administra los usuarios registrados en la plataforma.
</p>

<div class="table-responsive">

<!-- TABLA DE USUARIOS -->
<table class="table table-bordered table-hover bg-white shadow">

<tr class="table-dark">

<th>ID</th>
<th>Nombre</th>
<th>Email</th>
<th>Teléfono</th>
<th>Rol</th>
<th>Estado</th>
<th>Acciones</th>
</tr>

<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>
<?php echo $fila['id_usuario']; ?>
</td>

<td>
<?php echo $fila['nombre']; ?>
</td>

<td>
<?php echo $fila['email']; ?>
</td>

<td>
<?php echo $fila['telefono']; ?>
</td>

<td>

<!-- Mostrar el estado de la cuenta -->
<?php if($fila['estado']=="activo"){ ?>

<span class="badge bg-success">
Activo
</span>

<?php } else { ?>

<span class="badge bg-secondary">
Desactivado
</span>

<?php } ?>

</td>

<td>

<!-- Mostrar el rol del usuario  -->
<?php if($fila['rol'] == "admin"){ ?>

<span class="badge bg-danger">
Admin
</span>

<?php }else{ ?>

<span class="badge bg-primary">
Cliente
</span>

<?php } ?>

</td>

<td>

<!-- Permitir activar o desactivar usuarios que no sean administradores   -->
<?php if($fila['rol'] != "admin"){ ?>

    <?php if($fila['estado']=="activo"){ ?>

        <a
        href="admin_usuarios.php?desactivar=<?php echo $fila['id_usuario']; ?>"
        class="btn btn-warning btn-sm"
        onclick="confirmarDesactivacion(event,this.href)">

        Desactivar

        </a>

    <?php } else { ?>

        <a
href="admin_usuarios.php?activar=<?php echo $fila['id_usuario']; ?>"
class="btn btn-success btn-sm"
onclick="confirmarActivacion(event,this.href)">

Activar

</a>

    <?php } ?>

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

</div>

<div class="text-center mt-4">

<a href="admin.php" class="btn btn-dark">

Volver al panel

</a>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../js/script.js"></script>

</body>
</html>