<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar la librería PHPMailer */
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

global $conexion;

/* Variable para mostrar mensajes al usuario */
$mensaje = "";

/* Procesar la recuperación de contraseña */
if(isset($_POST['recuperar'])){

    $email = $_POST['email'];
    $telefono = $_POST['telefono'];

    /* Verificar que el email y teléfono pertenecen al mismo usuario */
$sql = "SELECT * FROM usuario
            WHERE email='$email'
            AND telefono='$telefono'";

    $resultado = mysqli_query($conexion, $sql);

    if(mysqli_num_rows($resultado) > 0){

       /* Generar una nueva contraseña temporal */
$nuevaPassword = rand(100000,999999);

/* Configurar el envío de correo mediante Gmail */
$mail = new PHPMailer(true);

        try {

            $mail->isSMTP();

            $mail->Host='smtp.gmail.com';

            $mail->SMTPAuth=true;

            $mail->Username='fullcourtbooking@gmail.com';

            $mail->Password='soln ywnm mypb uwdz';

            $mail->SMTPSecure='tls';

            $mail->Port=587;

            $mail->setFrom(
                'fullcourtbooking@gmail.com',
                'FullCourt'
            );

            $mail->addAddress($email);

            $mail->isHTML(true);

            $mail->Subject='Recuperación de contraseña';

            $mail->Body="

            <h2>Recuperación de contraseña</h2>

            <p>Tu nueva contraseña temporal es:</p>

            <h1>".$nuevaPassword."</h1>

            <p>
            Por seguridad cambia esta contraseña
            desde tu perfil después de iniciar sesión.
            </p>

            ";

            /* Enviar la nueva contraseña al correo del usuario */
             $mail->send();

            /* Actualizar la contraseña en la base de datos */
                $sqlActualizar = "UPDATE usuario
                  SET contraseña='$nuevaPassword'
                  WHERE email='$email'";

mysqli_query($conexion,$sqlActualizar);

            $mensaje = "
            <div class='alert alert-success text-center'>
            Se ha enviado una nueva contraseña a tu correo
            </div>";

            /* Mostrar error si no se puede enviar el correo */
        } catch(Exception $e){

            $mensaje = "
            <div class='alert alert-danger text-center'>
            Error al enviar el correo
            </div>";
        }

    }else{

        $mensaje = "
        <div class='alert alert-danger text-center'>
        El email o teléfono no coinciden
        </div>";
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Recuperar contraseña | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">
<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">
<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">
FullCourt
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="index.php">
Inicio
</a>
</li>

<?php if(isset($_SESSION['usuario'])){ ?>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

<?php }else{ ?>

<li class="nav-item">
<a class="nav-link" href="login.php">
Login
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="registro.php">
Registro
</a>
</li>

<?php } ?>

</ul>
</div>

</div>
</nav>

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-md-5">

<div class="card shadow border-0">

<div class="card-body p-5">

<h1 class="text-center mb-4">
Recuperar contraseña
</h1>

<?php echo $mensaje; ?>

<form method="POST">

<div class="mb-3">

<label class="form-label">
Correo electrónico
</label>

<input
type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-4">

<label class="form-label">
Teléfono
</label>

<input
type="text"
name="telefono"
class="form-control"
required>

</div>

<button
type="submit"
name="recuperar"
class="btn btn-success w-100">

Verificar datos

</button>

</form>

<div class="text-center mt-4">

<a href="login.php"
class="btn btn-outline-dark rounded-pill px-4">

<i class="bi bi-arrow-left me-2"></i>

Volver al login

</a>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

</body>
</html>