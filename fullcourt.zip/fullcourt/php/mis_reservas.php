<?php
/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

global $conexion;

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener los datos del usuario actual */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

/* Cancelar automáticamente reservas pendientes con más de 15 minutos */
$sqlCaducadas = "UPDATE reserva
                 SET estado='cancelada'
                 WHERE estado='pendiente'
                 AND fecha_creacion <= DATE_SUB(NOW(), INTERVAL 15 MINUTE)";

mysqli_query($conexion, $sqlCaducadas);

/* Cancelar una reserva del usuario */
if(isset($_GET['cancelar'])){

    $id_reserva = $_GET['cancelar'];

    /* Cambiar el estado de la reserva a cancelada */
        $sqlCancelar = "UPDATE reserva
                    SET estado='cancelada'
                    WHERE id_reserva='$id_reserva'
                    AND id_usuario='$id_usuario'";

    mysqli_query($conexion,$sqlCancelar);

    header("Location: mis_reservas.php");
    exit();
}

/* Obtener todas las reservas del usuario */
$sql = "SELECT reserva.*, pista.nombre
        FROM reserva
        INNER JOIN pista
        ON reserva.id_pista = pista.id_pista
        WHERE reserva.id_usuario='$id_usuario'
        ORDER BY fecha DESC,hora DESC";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Mis reservas | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">
<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">
<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">
FullCourt
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php">
Inicio
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_favoritos.php">
Favoritos
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>
</div>

</div>
</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-3">Mis reservas</h1>

<p class="text-center text-muted mb-5">
Aquí puedes consultar, pagar o cancelar tus reservas.
</p>

<div class="row g-4">

<!-- Mostrar reservas del usuario -->
<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<div class="col-md-4">

<div class="card shadow border-0">

<div class="card-body">

<h4 class="card-title">
    <?php echo $fila['nombre']; ?>
</h4>

<p>
<strong>Fecha:</strong>
<?php echo $fila['fecha']; ?>
</p>

<p>
<strong>Hora:</strong>
<?php echo $fila['hora']; ?>
</p>

<!-- Mostrar estado actual de la reserva -->
<div class="mb-3">

<strong>Estado:</strong>

<?php
if($fila['estado'] == "pendiente"){?>
   

<span class="badge bg-warning text-dark">
Pendiente
</span>

<a 
href="pago.php?id_reserva=<?php echo $fila['id_reserva']; ?>" 
class="btn btn-success w-100 mt-3">

Pagar reserva

</a>

<?php }elseif($fila['estado'] == 'pagada'){ ?>

<!-- Permitir el pago de reservas pendientes -->
<span class="badge bg-success">
Pagada
</span>

<?php }else{ ?>

<!-- Permitir cancelar reservas activas -->
<span class="badge bg-danger">
Cancelada
</span>

<?php } ?>
<?php if($fila['estado'] != 'cancelada'){ ?>

<a
href="mis_reservas.php?cancelar=<?php echo $fila['id_reserva']; ?>"
class="btn btn-danger w-100 mt-3"
onclick="confirmarCancelacion(event,this.href)">

Cancelar reserva

</a>


<?php } ?>
</div>

</div>

</div>

</div>

<?php } ?>

</div>

<div class="text-center mt-5">

<a href="index.php" class="btn btn-dark">
Volver al inicio
</a>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="../js/script.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>