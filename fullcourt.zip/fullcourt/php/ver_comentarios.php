<?php

session_start();

/* Conexión con la base de datos */
include("conexion.php");
global $conexion;

/* Obtener la pista seleccionada */
$id_pista = $_GET['id_pista'];

$sqlPista = "SELECT nombre
             FROM pista
             WHERE id_pista='$id_pista'";

$resultadoPista = mysqli_query($conexion,$sqlPista);

$pista = mysqli_fetch_assoc($resultadoPista);

/* Obtener los comentarios de la pista */
$sql = "SELECT comenta.texto,
               comenta.fecha,
               comenta.valoracion,
               usuario.nombre
        FROM comenta
        INNER JOIN usuario
        ON comenta.id_usuario = usuario.id_usuario
        WHERE comenta.id_pista='$id_pista'
        ORDER BY comenta.fecha DESC";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Comentarios | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a class="nav-link active fw-bold" href="perfil.php">
Perfil
</a>

</li>

<li class="nav-item">

<a class="nav-link" href="index.php">
Inicio
</a>

</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<div class="container py-5">

<h1 class="text-center mb-5">
Comentarios de <?php echo $pista['nombre']; ?>
</h1>
<div class="row g-4">

<!-- Mostrar comentarios -->
<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<div class="col-md-6">

<div class="card shadow border-0 h-100">

<div class="card-body">

<h5 class="fw-bold">
<?php echo $fila['nombre']; ?>
</h5>

<p class="text-warning fs-5">

<!-- Mostrar valoración mediante estrellas -->
<?php
for($i=0; $i<$fila['valoracion']; $i++){
    echo "⭐";
}
?>

</p>

<p>
<?php echo $fila['texto']; ?>
</p>

<p class="text-muted small">
<?php echo $fila['fecha']; ?>
</p>

</div>

</div>

</div>

<?php } ?>

</div>

<div class="text-center mt-5">

<a href="index.php" class="btn btn-dark">
Volver
</a>

</div>

</div>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

</body>
</html>