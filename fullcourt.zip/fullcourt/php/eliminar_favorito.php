<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

global $conexion;

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener la pista que se quiere eliminar de favoritos */
$id_pista = $_GET['id_pista'];

/* Obtener los datos del usuario actual */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

/* Eliminar la pista de la lista de favoritos */
$sqlEliminar = "DELETE FROM favorita
                WHERE id_usuario='$id_usuario'
                AND id_pista='$id_pista'";

mysqli_query($conexion, $sqlEliminar);

/* Redirigir a la página de favoritos */
header("Location: mis_favoritos.php");
exit();
?>