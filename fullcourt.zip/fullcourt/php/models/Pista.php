<?php

require_once __DIR__ . '/../config/Database.php';

/* Modelo encargado de gestionar las pistas deportivas */
class Pista {

    private $conexion;

    /* Crear conexión con la base de datos */
    public function __construct() {

        $database = new Database();
        $this->conexion = $database->conectar();

    }

    /* Obtener todas las pistas registradas */
    public function obtenerTodas() {

        $sql = "SELECT * FROM pista";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        return $resultado;
    }

    /* Obtener el número total de pistas */
    public function contarPistas(){

        $sql = "SELECT COUNT(*) AS total
                FROM pista";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        $fila = mysqli_fetch_assoc($resultado);

        return $fila['total'];
    }

}