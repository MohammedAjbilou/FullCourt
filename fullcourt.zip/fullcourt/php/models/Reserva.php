<?php

require_once __DIR__ . '/../config/Database.php';

/* Modelo encargado de gestionar las reservas */
class Reserva {

    private $conexion;

    /* Crear conexión con la base de datos */
    public function __construct() {

        $database = new Database();
        $this->conexion = $database->conectar();

    }

    /* Obtener todas las reservas registradas */
    public function obtenerTodas() {

        $sql = "SELECT * FROM reserva";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        return $resultado;
    }

    /* Obtener el número total de reservas */
    public function contarReservas(){

         $sql = "SELECT COUNT(*) AS total
            FROM reserva
            WHERE estado='pagada'";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        $fila = mysqli_fetch_assoc($resultado);

        return $fila['total'];
    }

}