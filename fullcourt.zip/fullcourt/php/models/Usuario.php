<?php

require_once __DIR__ . '/../config/Database.php';

/* Modelo encargado de gestionar los usuarios */
class Usuario {

    private $conexion;

    /* Crear conexión con la base de datos */
    public function __construct() {

        $database = new Database();
        $this->conexion = $database->conectar();
    }

    /* Buscar un usuario por su nombre */
    public function buscarPorNombre($nombre){

        $sql = "SELECT * FROM usuario
                WHERE nombre='$nombre'";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        return mysqli_fetch_assoc($resultado);
    }

    /* Comprobar credenciales de inicio de sesión */
    public function login($email, $contraseña){

        $sql = "SELECT * FROM usuario
                WHERE email='$email'
                AND contraseña='$contraseña'";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        return mysqli_fetch_assoc($resultado);
    }

    /* Obtener el número total de usuarios */
    public function contarUsuarios(){

        $sql = "SELECT COUNT(*) AS total
                FROM usuario";

        $resultado = mysqli_query(
            $this->conexion,
            $sql
        );

        $fila = mysqli_fetch_assoc($resultado);

        return $fila['total'];
    }

}