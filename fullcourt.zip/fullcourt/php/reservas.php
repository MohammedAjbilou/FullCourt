<?php
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo de usuarios */
require_once "models/Usuario.php";

global $conexion;

/* Obtener el deporte seleccionado */
$deporte = $_GET['deporte'];

/* Variables para mostrar mensajes al usuario */
$mensaje = "";
$tipoMensaje = "";

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
}

/* Procesar la reserva cuando se envía el formulario */
if(isset($_POST['reservar'])){

    $id_pista = $_POST['id_pista'];

    $fecha = $_POST['fecha'];

    $hora = $_POST['hora'];

/* Comprobar que la reserva no sea en domingo */
 if(date('w', strtotime($fecha)) == 0){

        $mensaje = "Los domingos las instalaciones están cerradas";
        $tipoMensaje = "danger";

/* Comprobar horario de los sábados */
}elseif(date('w', strtotime($fecha)) == 6 && $hora > "20:00"){

    $mensaje = "Los sábados solo se puede reservar hasta las 20:00";
    $tipoMensaje = "danger";

    }else{

/* Obtener el usuario que realiza la reserva */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

/* Comprobar si la pista ya está reservada */
        $sqlComprobar = "SELECT * FROM reserva
                         WHERE fecha='$fecha'
                         AND hora='$hora'
                         AND id_pista='$id_pista'
                         AND estado!='cancelada'";

        $resultadoComprobar = mysqli_query($conexion, $sqlComprobar);

        if(mysqli_num_rows($resultadoComprobar) > 0){

            $mensaje = "Esa pista ya está reservada en esa fecha y hora";
            $tipoMensaje = "danger";

        }else{

        /* Crear la reserva en la base de datos */
        $fecha_creacion = date("Y-m-d H:i:s");

            $sqlReserva = "INSERT INTO reserva
              (fecha,hora,estado,id_usuario,id_pista,fecha_creacion)
              VALUES
              ('$fecha','$hora','pendiente','$id_usuario','$id_pista','$fecha_creacion')";

            mysqli_query($conexion, $sqlReserva);

            $mensaje = "Reserva realizada correctamente";
            $tipoMensaje = "success";

        }
    }
}



/* Obtener las horas ocupadas de una pista */
$horasOcupadas = [];

if(isset($_POST['fecha']) && isset($_POST['id_pista'])){

    $fechaSeleccionada = $_POST['fecha'];
    $pistaSeleccionada = $_POST['id_pista'];

    $sqlHoras = "SELECT hora FROM reserva
                 WHERE fecha='$fechaSeleccionada'
                 AND id_pista='$pistaSeleccionada'
                 AND estado!='cancelada'";

    $resultadoHoras = mysqli_query($conexion, $sqlHoras);

    while($filaHora = mysqli_fetch_assoc($resultadoHoras)){

        $horasOcupadas[] = $filaHora['hora'];

    }
}

/* Obtener las pistas del deporte seleccionado */
$sql = "SELECT pista.*
        FROM pista
        INNER JOIN pista_deporte
        ON pista.id_pista = pista_deporte.id_pista
        INNER JOIN deporte
        ON pista_deporte.id_deporte = deporte.id_deporte
        WHERE deporte.nombre_deporte='$deporte'";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Completa tu reserva | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../styles.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php">
Inicio
</a>
</li>

<?php if(isset($_SESSION['usuario'])){ ?>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_favoritos.php">
Favoritos
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

<?php }else{ ?>

<li class="nav-item">
<a class="nav-link" href="login.php">
Login
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="registro.php">
Registro
</a>
</li>

<?php } ?>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<div class="row justify-content-center">

<div class="col-md-7 col-lg-6">

<div class="card shadow border-0">

<div class="card-body p-5">

<h1 class="text-center mb-3">
Completa tu reserva
</h1>

<p class="text-center text-muted mb-4">
Rellena los siguientes campos para confirmar tu reserva deportiva.
</p>

<?php if($mensaje != ""){ ?>

<div class="alert alert-<?php echo $tipoMensaje; ?> text-center">

<?php echo $mensaje; ?>

</div>

<!-- Formulario de reserva -->
<?php } ?>

<form method="POST">

<div class="alert alert-success text-center mb-4">

Reservando pista de:

<strong>
<?php echo ucfirst($deporte); ?>
</strong>

</div>

<div class="mb-3">

<label class="form-label">
Selecciona pista
</label>

<select
name="id_pista"
class="form-select"
required>

<option value="">
Selecciona una pista
</option>

<?php while($pista = mysqli_fetch_assoc($resultado)){ ?>

<option value="<?php echo $pista['id_pista']; ?>">

<?php echo $pista['nombre']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label for="fecha" class="form-label">
Fecha de reserva
</label>

<input
type="date"
class="form-control"
name="fecha"
min="<?php echo date('Y-m-d'); ?>"
required>

</div>

<div class="mb-4">

<label for="hora" class="form-label">
Hora
</label>

<select
class="form-select"
name="hora"
required>

<option value="">
Selecciona una hora
</option>

<option value="09:00">09:00</option>
<option value="10:00">10:00</option>
<option value="11:00">11:00</option>
<option value="12:00">12:00</option>
<option value="13:00">13:00</option>
<option value="14:00">14:00</option>
<option value="15:00">15:00</option>
<option value="16:00">16:00</option>
<option value="17:00">17:00</option>
<option value="18:00">18:00</option>
<option value="19:00">19:00</option>
<option value="20:00">20:00</option>
<option value="21:00">21:00</option>
<option value="22:00">22:00</option>

</select>

</div>

<!-- Información meteorológica -->
<div id="clima" class="alert alert-info text-center mb-4">

Consultando tiempo...

</div>

<div class="d-grid">

<button type="submit" name="reservar" class="btn btn-primary btn-lg">
Confirmar reserva
</button>

</div>

</form>

<div class="text-center mt-4">

<a href="index.php" class="btn btn-outline-danger">
Cancelar
</a>

</div>

</div>

</div>

</div>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>