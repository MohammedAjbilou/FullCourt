<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

global $conexion;

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener los datos del usuario actual */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

/* Obtener las pistas marcadas como favoritas por el usuario */
$sql = "SELECT favorita.*,
               pista.nombre,
               deporte.nombre_deporte
        FROM favorita
        INNER JOIN pista
        ON favorita.id_pista = pista.id_pista
        INNER JOIN pista_deporte
        ON pista.id_pista = pista_deporte.id_pista
        INNER JOIN deporte
        ON pista_deporte.id_deporte = deporte.id_deporte
        WHERE favorita.id_usuario='$id_usuario'";
$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Mis favoritos | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="mis_favoritos.php">
Favoritos
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php">
Inicio
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-5">
Mis favoritos
</h1>

<div class="row g-4">

<!-- Mostrar lista de pistas favoritas -->
<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<div class="col-md-4">

<div class="card shadow border-0 h-100">

<div class="card-body text-center">

<h3>
<?php echo $fila['nombre']; ?>
</h3>

<p class="text-muted">
<?php echo $fila['nombre_deporte']; ?>
</p>

<!-- Eliminar pista de favoritos -->
<a 
href="eliminar_favorito.php?id_pista=<?php echo $fila['id_pista']; ?>" 
class="btn btn-outline-danger mt-3 w-100">

Eliminar favorito

</a>

<!-- Reservar directamente una pista favorita -->
<a
href="reservas.php?deporte=<?php echo strtolower($fila['nombre_deporte']); ?>"
class="btn btn-success mt-2 w-100">

Reservar pista

</a>

<p class="text-muted">
Pista añadida a favoritos
</p>

</div>

</div>

</div>

<?php } ?>

</div>

<div class="text-center mt-4">

<a href="index.php" class="btn btn-dark">

Volver al inicio

</a>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>