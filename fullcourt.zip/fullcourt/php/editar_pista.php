<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

global $conexion;

/* Verificar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* Obtener el identificador de la pista a editar */
$id = $_GET['id'];
/* Obtener los datos actuales de la pista y su deporte */
$sql = "SELECT pista.*,
               deporte.id_deporte
        FROM pista
        INNER JOIN pista_deporte
        ON pista.id_pista = pista_deporte.id_pista
        INNER JOIN deporte
        ON pista_deporte.id_deporte = deporte.id_deporte
        WHERE pista.id_pista='$id'";

$resultado = mysqli_query($conexion,$sql);

/* Guardar los datos recuperados en un array */
$fila = mysqli_fetch_assoc($resultado);

/* Procesar el formulario cuando se pulse Guardar */
if(isset($_POST['guardar'])){

/* Obtener los nuevos datos introducidos por el administrador */
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $deporte = $_POST['deporte'];

/* Actualizar nombre y precio de la pista */
$sqlActualizar = "UPDATE pista
                       SET nombre='$nombre',
                           precio_hora='$precio'
                       WHERE id_pista='$id'";

    mysqli_query($conexion,$sqlActualizar);

   /* Actualizar el deporte asociado a la pista */
$sqlDeporte = "UPDATE pista_deporte
                   SET id_deporte='$deporte'
                   WHERE id_pista='$id'";

    mysqli_query($conexion,$sqlDeporte);

/* Volver a la gestión de pistas tras guardar los cambios */
header("Location: admin_pistas.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Editar pista</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<div class="container py-5">

<div class="row justify-content-center">

<div class="col-md-6">

<div class="card shadow">

<div class="card-body p-5">

<h2 class="text-center mb-4">

Editar pista

</h2>

<form method="POST">

<div class="mb-3">

<label>Nombre</label>

<input
type="text"
name="nombre"
class="form-control"
value="<?php echo $fila['nombre']; ?>"
required>

</div>

<div class="mb-3">

<label>Precio por hora</label>

<input
type="number"
step="0.01"
name="precio"
class="form-control"
value="<?php echo $fila['precio_hora']; ?>"
required>

</div>

<div class="mb-4">

<label>Deporte</label>

<select
name="deporte"
class="form-select">

<option value="1"
<?php if($fila['id_deporte']==1) echo "selected"; ?>>

Fútbol

</option>

<option value="2"
<?php if($fila['id_deporte']==2) echo "selected"; ?>>

Baloncesto

</option>

<option value="3"
<?php if($fila['id_deporte']==3) echo "selected"; ?>>

Pádel

</option>

</select>

</div>

<button
type="submit"
name="guardar"
class="btn btn-success w-100">

Guardar cambios

</button>

</form>

</div>

</div>

</div>

</div>

</div>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>
</body>
</html>