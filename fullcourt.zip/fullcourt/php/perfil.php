<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo de usuarios */
require_once "models/Usuario.php";

global $conexion;

$mensaje = "";

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener los datos del usuario actual */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

/* Obtener número total de reservas del usuario */
$sqlReservas = "SELECT COUNT(*) AS totalReservas
                FROM reserva
                WHERE id_usuario='".$usuario['id_usuario']."'";

$resultadoReservas = mysqli_query($conexion, $sqlReservas);

$totalReservas = mysqli_fetch_assoc($resultadoReservas);

/* Obtener número total de favoritos del usuario */
$sqlFavoritos = "SELECT COUNT(*) AS totalFavoritos
                 FROM favorita
                 WHERE id_usuario='".$usuario['id_usuario']."'";

$resultadoFavoritos = mysqli_query($conexion, $sqlFavoritos);

$totalFavoritos = mysqli_fetch_assoc($resultadoFavoritos);

/* Actualizar datos personales o contraseña */
if(isset($_POST['guardar']) || isset($_POST['cambiar_password'])){

    $nuevoNombre = $_POST['nombre'];
    $nuevoTelefono = $_POST['telefono'];

    $actual = $_POST['actual'];
    $nueva = $_POST['nueva'];
    $repetir = $_POST['repetir'];

    /* Comprobar si el usuario quiere cambiar la contraseña */
if(!empty($actual) || !empty($nueva) || !empty($repetir)){

        if($actual != $usuario['contraseña']){

            $mensaje = "<div class='alert alert-danger text-center'>
La contraseña actual es incorrecta
</div>";

        }elseif($nueva != $repetir){

            $mensaje = "<div class='alert alert-danger text-center'>
Las nuevas contraseñas no coinciden
</div>";

        }else{

            /* Actualizar nombre, teléfono y contraseña */
                                $sqlActualizar = "UPDATE usuario
                              SET nombre='$nuevoNombre',
                                  telefono='$nuevoTelefono',
                                  contraseña='$nueva'
                              WHERE id_usuario='".$usuario['id_usuario']."'";

            mysqli_query($conexion, $sqlActualizar);

            $_SESSION['usuario'] = $nuevoNombre;

            $mensaje = "<div class='alert alert-success text-center'>
Contraseña actualizada correctamente
</div>";

        }

    }else{

    /* Actualizar únicamente los datos personales */
        $sqlActualizar = "UPDATE usuario
                          SET nombre='$nuevoNombre',
                              telefono='$nuevoTelefono'
                          WHERE id_usuario='".$usuario['id_usuario']."'";

        mysqli_query($conexion, $sqlActualizar);

        $_SESSION['usuario'] = $nuevoNombre;

        $mensaje = "<div class='alert alert-success text-center'>
Datos actualizados correctamente
</div>";

    }

}
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Perfil | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<link rel="stylesheet" href="../styles.css">

</head>

<body style="background:#f4f7f5;">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a class="nav-link active fw-bold" href="perfil.php">
Perfil
</a>

</li>

<li class="nav-item">

<a class="nav-link" href="index.php">
Inicio
</a>

</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="container py-5">

<div class="row justify-content-center">

<div class="col-lg-9">

<!-- TARJETA PERFIL -->
<div class="card border-0 shadow-lg mb-4 rounded-4">

<div class="card-body p-5 text-center">

<img
src="../icons/usuario.png"
class="mb-3"
width="120"
style="object-fit:contain;">

<h1 class="fw-bold" style="color:#14532d;">

Panel de usuario

</h1>

<p class="fs-5 text-muted mb-4">

<?php echo $mensaje; ?>

Bienvenido de nuevo,
<strong><?php echo $_SESSION['usuario']; ?></strong>

</p>

<hr class="mb-4">

<div class="row text-start">

<div class="col-md-6 mb-3">

<p>

<i class="bi bi-envelope-fill text-success me-2"></i>

<strong>Email:</strong>

<?php echo $usuario['email']; ?>

</p>

</div>

<div class="col-md-6 mb-3">

<p>

<i class="bi bi-telephone-fill text-success me-2"></i>

<strong>Teléfono:</strong>

<?php echo $usuario['telefono']; ?>

</p>

</div>

</div>

<hr class="my-4">

<div class="text-center mb-4">

<button
class="btn btn-success"
type="button"
data-bs-toggle="collapse"
data-bs-target="#editarPerfil">

Modificar datos

</button>

</div>

<div class="collapse" id="editarPerfil">

<h3 class="text-center fw-bold mb-4" style="color:#14532d;">

Editar datos personales

</h3>

<form method="POST">

<div class="row g-4">

<div class="col-md-6">

<label class="form-label fw-bold">
Nombre
</label>

<input
type="text"
name="nombre"
class="form-control"
value="<?php echo $usuario['nombre']; ?>"
required>

</div>

<div class="col-md-6">

<label class="form-label fw-bold">
Teléfono
</label>

<input
type="text"
name="telefono"
class="form-control"
value="<?php echo $usuario['telefono']; ?>"
required>

</div>

</div>


<div class="d-grid mt-4">

<button type="submit" name="guardar" class="btn btn-success btn-lg">

Guardar cambios

</button>

</div>

<div class="text-center mt-4">

<button
class="btn btn-warning"
type="button"
data-bs-toggle="collapse"
data-bs-target="#cambiarPassword">

Cambiar contraseña

</button>

</div>

<div class="collapse mt-4" id="cambiarPassword">

<h4 class="fw-bold mb-4 text-center" style="color:#14532d;">

Modificar contraseña

</h4>

<div class="row g-4">

<div class="col-md-4">

<label class="form-label fw-bold">
Contraseña actual
</label>

<input
type="password"
name="actual"
class="form-control"
required>

</div>

<div class="col-md-4">

<label class="form-label fw-bold">
Nueva contraseña
</label>

<input
type="password"
name="nueva"
class="form-control"
required>

</div>

<div class="col-md-4">

<label class="form-label fw-bold">
Repetir contraseña
</label>

<input
type="password"
name="repetir"
class="form-control"
required>

</div>

</div>

<div class="d-grid mt-4">

<button
type="submit"
name="cambiar_password"
class="btn btn-warning btn-lg">

Actualizar contraseña

</button>

</div>

</form>

</div>

</div>
</div>

</div>

<!-- ESTADISTICAS -->
<div class="row g-4 mb-4">

<div class="col-md-6">

<div class="card border-0 shadow h-100 text-center bg-success text-white rounded-4">

<div class="card-body p-4">

<i class="bi bi-calendar-check fs-1 text-white"></i>

<h2 class="fw-bold mt-3 text-white">

<?php echo $totalReservas['totalReservas']; ?>

</h2>

<p class="mb-0 text-white">
Reservas realizadas
</p>

</div>

</div>

</div>

<div class="col-md-6">

<div class="card border-0 shadow h-100 text-center bg-warning rounded-4">

<div class="card-body p-4">

<i class="bi bi-heart-fill fs-1 text-dark"></i>

<h2 class="fw-bold mt-3 text-dark">

<?php echo $totalFavoritos['totalFavoritos']; ?>

</h2>

<p class="mb-0 text-dark">
Pistas favoritas
</p>

</div>

</div>

</div>

</div>



<!-- ACCIONES -->
<div class="row g-4 mt-2">

<div class="col-md-6">

<a href="mis_reservas.php"
class="btn btn-light w-100 py-4 shadow border rounded-4 accion-card">

<i class="bi bi-calendar2-check fs-2 d-block mb-2 text-success"></i>

<span class="fs-4 fw-bold text-dark">
Mis reservas
</span>

<br>

<small class="text-muted">
Consulta y gestiona tus reservas
</small>

</a>

</div>

<div class="col-md-6">

<a href="mis_favoritos.php"
class="btn btn-light w-100 py-4 shadow border rounded-4 accion-card">

<i class="bi bi-heart-fill fs-2 d-block mb-2 text-danger"></i>

<span class="fs-4 fw-bold text-dark">
Mis favoritos
</span>

<br>

<small class="text-muted">
Accede rápidamente a tus favoritos
</small>

</a>

</div>

<div class="col-md-6">

<a href="mis_incidencias.php"
class="btn btn-light w-100 py-4 shadow border rounded-4 accion-card">

<i class="bi bi-exclamation-triangle-fill fs-2 d-block mb-2 text-warning"></i>

<span class="fs-4 fw-bold text-dark">
Mis incidencias
</span>

<br>

<small class="text-muted">
Consulta incidencias y estados
</small>

</a>

</div>

</div>

<!-- LOGOUT -->
<div class="text-center mt-5">

<a href="logout.php"
class="btn btn-danger btn-lg px-5 rounded-pill shadow">

<i class="bi bi-box-arrow-right me-2"></i>

Cerrar sesión

</a>

</div>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>