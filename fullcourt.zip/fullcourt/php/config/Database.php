<?php

/* Clase encargada de gestionar la conexión con la base de datos */
class Database {

    /* Datos de conexión */
    private $host = "localhost";
    private $usuario = "root";
    private $password = "";
    private $bd = "fullcourt";

    /* Crear y devolver la conexión */
    public function conectar() {

        $conexion = mysqli_connect(
            $this->host,
            $this->usuario,
            $this->password,
            $this->bd
        );

        return $conexion;
    }
}