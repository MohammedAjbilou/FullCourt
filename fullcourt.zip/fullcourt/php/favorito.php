<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

global $conexion;

/* Verificar que el usuario ha iniciado sesión */
if(!isset($_SESSION['usuario'])){
    header("Location: login.php");
    exit();
}

/* Obtener la pista seleccionada */
$id_pista = $_GET['id_pista'];

/* Obtener datos del usuario actual */
$usuarioModel = new Usuario();

$usuario = $usuarioModel->buscarPorNombre(
    $_SESSION['usuario']
);

$id_usuario = $usuario['id_usuario'];

/* Comprobar si la pista ya está en favoritos */
$sqlComprobar = "SELECT * FROM favorita
                 WHERE id_usuario='$id_usuario'
                 AND id_pista='$id_pista'";

$resultadoComprobar = mysqli_query($conexion, $sqlComprobar);

/* Añadir a favoritos si todavía no existe */
if(mysqli_num_rows($resultadoComprobar) == 0){

    $sqlInsertar = "INSERT INTO favorita(id_usuario,id_pista)
                    VALUES('$id_usuario','$id_pista')";

    mysqli_query($conexion, $sqlInsertar);
}

/* Volver a la página principal mostrando confirmación */
header("Location: index.php?favorito=ok");
exit();
?>