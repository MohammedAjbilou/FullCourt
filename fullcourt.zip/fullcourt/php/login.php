<?php

/* Iniciar sesión */
session_start();

/* Conexión con la base de datos */
include("conexion.php");

/* Cargar modelo Usuario */
require_once "models/Usuario.php";

/* Variable para mostrar mensajes al usuario */
$mensaje = "";

/* MENSAJE DESPUÉS DEL REGISTRO */
if(isset($_GET['registro'])){

    $mensaje = '
    <div class="alert text-center border-0 shadow-sm"
style="background:#dcfce7; color:#166534;">
        Cuenta creada correctamente. Ya puedes iniciar sesión.
    </div>
    ';

}

/* Procesar el inicio de sesión */
if(isset($_POST['login'])){

    $email = $_POST['email'];
    $contraseña = $_POST['contraseña'];

    /* Comprobar credenciales del usuario */
$usuarioModel = new Usuario();

/* Buscar usuario por email y contraseña */
$usuario = $usuarioModel->login(
    $email,
    $contraseña
);

if($usuario){

        /* Verificar que la cuenta no esté desactivada */
if($usuario['estado'] == "desactivado"){

            $mensaje = '
            <div class="alert alert-warning text-center">
                Tu cuenta está desactivada
            </div>
            ';

        }else{

        /* Crear variables de sesión */
            $_SESSION['usuario'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol'];

            /* Redirigir según el tipo de usuario */
            if($usuario['rol'] == "admin"){

                header("Location: admin.php");

            }else{

                header("Location: index.php");

            }

            exit();
        }

    }else{

    /* Mostrar error si las credenciales son incorrectas */
        $mensaje = '
        <div class="alert alert-danger text-center">
            Email o contraseña incorrectos
        </div>
        ';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Mi cuenta | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../styles.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">
<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">
<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">
FullCourt
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="index.php">
Inicio
</a>
</li>

<?php if(isset($_SESSION['usuario'])){ ?>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

<?php }else{ ?>

<li class="nav-item">
<a class="nav-link" href="login.php">
Login
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="registro.php">
Registro
</a>
</li>

<?php } ?>

</ul>
</div>

</div>
</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<div class="row justify-content-center">

<div class="col-md-6">

<div class="card shadow border-0">

<div class="card-body p-5">

<h1 class="text-center mb-4">Mi cuenta</h1>

<?php if($mensaje != ""){ ?>

<?php echo $mensaje; ?>

<?php } ?>

<form method="POST" autocomplete="off">

<div class="mb-3">

<label for="email" class="form-label">
Correo electrónico
</label>

<input 
type="email" 
class="form-control"
id="email"
name="email"
placeholder="ejemplo@email.com"
autocomplete="new-password"
required>

</div>

<div class="mb-4">

<label for="pass" class="form-label">
Contraseña
</label>

<input 
type="password"
class="form-control"
id="pass"
name="contraseña"
placeholder="Contraseña"
autocomplete="new-password"
required>

</div>

<div class="d-grid">

<button type="submit" name="login" class="btn btn-primary btn-lg">
Iniciar sesión
</button>

<div class="text-center mt-3">

<a href="recuperar_password.php">

¿Has olvidado tu contraseña?

</a>

</div>

</div>

</form>

<p class="text-center mt-4 mb-0">

¿No tienes cuenta?

<a href="registro.php">
Regístrate aquí
</a>

</p>

</div>
</div>

</div>
</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>