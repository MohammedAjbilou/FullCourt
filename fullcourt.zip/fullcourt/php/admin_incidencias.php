<?php
session_start();

include("conexion.php");
global $conexion;

/* Comprobar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* Cambiar estado de la incidencia a revisada */
if(isset($_GET['revisar'])){

    $id = $_GET['revisar'];

    mysqli_query($conexion,
    "UPDATE incidencia
     SET estado='revisada'
     WHERE id_incidencia='$id'");

    header("Location: admin_incidencias.php");
    exit();
}

/* Cambiar estado de la incidencia a solucionada */
if(isset($_GET['solucionar'])){

    $id = $_GET['solucionar'];

    mysqli_query($conexion,
    "UPDATE incidencia
     SET estado='solucionada'
     WHERE id_incidencia='$id'");

    header("Location: admin_incidencias.php");
    exit();
}

/* Guardar respuesta del administrador a la incidencia */
if(isset($_POST['responder'])){

    $id = $_POST['id_incidencia'];
    $respuesta = $_POST['respuesta'];

    mysqli_query($conexion,
    "UPDATE incidencia
     SET respuesta='$respuesta'
     WHERE id_incidencia='$id'");

    header("Location: admin_incidencias.php");
    exit();
}

/* Obtener todas las incidencias junto con el nombre del usuario */
$sql = "SELECT incidencia.*,
               usuario.nombre

        FROM incidencia

        INNER JOIN usuario
        ON incidencia.id_usuario = usuario.id_usuario";

$resultado = mysqli_query($conexion,$sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Gestión de incidencias</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="admin.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_comentarios.php">
Comentarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<div class="container py-5" style="min-height:70vh;">

<h1 class="text-center mb-5">
Gestión de incidencias
</h1>

<!-- TABLA DE INCIDENCIAS -->
 <div class="table-responsive">
<table class="table table-bordered bg-white shadow">

<tr class="table-dark">

<th>ID</th>
<th>Usuario</th>
<th>Descripción</th>
<th>Estado</th>
<th>Respuesta</th>
<th>Acciones</th>

</tr>
<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>
<?php echo $fila['id_incidencia']; ?>
</td>

<td>
<?php echo $fila['nombre']; ?>
</td>

<td>
<?php echo $fila['descripcion']; ?>
</td>

<td>
<?php echo $fila['estado']; ?>
</td>

<td>

<?php echo $fila['respuesta']; ?>

</td>

<td>

<!-- Acciones para gestionar la incidencia -->
<a
href="admin_incidencias.php?revisar=<?php echo $fila['id_incidencia']; ?>"
class="btn btn-warning btn-sm">

Revisada

</a>

<a
href="admin_incidencias.php?solucionar=<?php echo $fila['id_incidencia']; ?>"
class="btn btn-success btn-sm">

Solucionada

</a>

<form method="POST" class="mt-2">

<input type="hidden"
name="id_incidencia"
value="<?php echo $fila['id_incidencia']; ?>">

<textarea
name="respuesta"
class="form-control mb-2"
placeholder="Escribe una respuesta..."
required></textarea>

<button
type="submit"
name="responder"
class="btn btn-primary btn-sm">

Guardar respuesta

</button>

</form>

</td>

</tr>

<?php } ?>

</table>

</div>

<div class="text-center mt-4">

<a href="admin.php" class="btn btn-dark">

Volver al panel

</a>

</div>

</div>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>