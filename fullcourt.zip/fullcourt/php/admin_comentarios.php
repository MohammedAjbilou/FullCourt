<?php
session_start();

include("conexion.php");
global $conexion;

/* Comprobar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* ELIMINAR COMENTARIO */
if(isset($_GET['eliminar'])){

    $id = $_GET['eliminar'];

    $sqlEliminar = "DELETE FROM comenta
                    WHERE id_comentario='$id'";

    mysqli_query($conexion, $sqlEliminar);

    header("Location: admin_comentarios.php");
    exit();
}
/* OBTENER COMENTARIOS */
$sql = "SELECT comenta.*,
               usuario.nombre AS usuario,
               pista.nombre AS pista
        FROM comenta

        INNER JOIN usuario
        ON comenta.id_usuario = usuario.id_usuario

        INNER JOIN pista
        ON comenta.id_pista = pista.id_pista

        ORDER BY comenta.fecha DESC";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Comentarios | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="admin.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin_comentarios.php">
Comentarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-3">
Comentarios y valoraciones
</h1>

<p class="text-center text-muted mb-5">
Gestiona los comentarios publicados por los usuarios.
</p>

<!-- TABLA DE COMENTARIOS -->
<div class="table-responsive">

<table class="table table-bordered table-hover bg-white shadow align-middle">

<tr class="table-dark">

<th>Usuario</th>
<th>Pista</th>
<th>Comentario</th>
<th>Valoración</th>
<th>Fecha</th>
<th>Acciones</th>

</tr>

<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>
<?php echo $fila['usuario']; ?>
</td>

<td>
<?php echo $fila['pista']; ?>
</td>

<td style="max-width:300px;">
<?php echo $fila['texto']; ?>
</td>

<td class="text-warning fs-5">

<?php

/* Convertir la valoración numérica en estrellas */
$valoracion = $fila['valoracion'];

for($i = 1; $i <= 5; $i++){

    if($i <= $valoracion){
        echo "★";
    }else{
        echo "☆";
    }
}
?>

</td>

<td>
<?php echo $fila['fecha']; ?>
</td>

<td>

<!-- Botón para eliminar comentario -->
<a
href="admin_comentarios.php?eliminar=<?php echo $fila['id_comentario']; ?>"
class="btn btn-danger btn-sm"
onclick="confirmarEliminarComent(event,this.href)">

Eliminar

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<div class="text-center mt-4">

<a href="admin.php" class="btn btn-dark">

Volver al panel

</a>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../js/script.js"></script>

</body>
</html>