<?php
/* Conexión con la base de datos */
include("conexion.php");
global $conexion;

session_start();

/* Procesar el registro de un nuevo usuario */
if(isset($_POST['registrar'])){

    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $rol = "cliente";
    $contraseña = $_POST['contraseña'];

    $repetir = $_POST['repetir'];

/* Verificar que las contraseñas coinciden */
if($contraseña != $repetir){

    echo "<script>
    alert('Las contraseñas no coinciden');
    window.history.back();
    </script>";

    exit();

}

/* Registrar el nuevo usuario en la base de datos */
    $sql = "INSERT INTO usuario(nombre,email,telefono,rol,contraseña)
            VALUES('$nombre','$email','$telefono','$rol','$contraseña')";

    mysqli_query($conexion, $sql);

    header("Location: login.php?registro=ok");
    exit();

}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Registro | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../styles.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">
<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="index.php">
<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">
FullCourt
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link active fw-bold" href="index.php">
Inicio
</a>
</li>

<?php if(isset($_SESSION['usuario'])){ ?>

<li class="nav-item">
<a class="nav-link" href="perfil.php">
Perfil
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="mis_reservas.php">
Mis reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

<?php }else{ ?>

<li class="nav-item">
<a class="nav-link" href="login.php">
Login
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="registro.php">
Registro
</a>
</li>

<?php } ?>

</ul>
</div>

</div>
</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<div class="row justify-content-center">

<div class="col-md-7 col-lg-6">

<div class="card shadow border-0">

<div class="card-body p-5">

<h1 class="text-center mb-4">Crear cuenta</h1>

<form method="POST" autocomplete="off">

<div class="mb-3">
<label for="nombre" class="form-label">Nombre completo</label>

<input
type="text"
class="form-control"
id="nombre"
name="nombre"
placeholder="Nombre completo"
required>

</div>

<div class="mb-3">

<label for="email" class="form-label">Correo electrónico</label>

<input
type="email"
class="form-control"
id="email"
name="email"
placeholder="ejemplo@email.com"
autocomplete="new-password"
required>

</div>

<div class="mb-3">

<label for="telefono" class="form-label">Teléfono</label>

<input
type="tel"
class="form-control"
id="telefono"
name="telefono"
placeholder="600123456"
pattern="[0-9]{9}">

</div>

<div class="mb-3">

<label for="pass" class="form-label">Contraseña</label>

<input
type="password"
class="form-control"
id="pass"
name="contraseña"
placeholder="Contraseña"
autocomplete="new-password"
minlength="6"
required>
</div>

<div class="mb-4">

<label for="pass2" class="form-label">Repetir contraseña</label>

<input
type="password"
class="form-control"
id="pass2"
name="repetir"
placeholder="Repite la contraseña"
minlength="6"
required>

</div>

<div class="d-grid">

<button type="submit" name="registrar" class="btn btn-primary btn-lg">
Registrarse
</button>

</div>

</form>

</div>
</div>

</div>
</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>