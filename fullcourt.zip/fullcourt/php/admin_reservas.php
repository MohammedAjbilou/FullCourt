<?php
session_start();

include("conexion.php");

require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

global $conexion;

/* Comprobar que el usuario es administrador */
if(!isset($_SESSION['usuario']) || $_SESSION['rol'] != "admin"){
    header("Location: login.php");
    exit();
}

/* Cancelar automáticamente reservas pendientes con más de 15 minutos */
$sqlCaducadas = "UPDATE reserva
                 SET estado='cancelada'
                 WHERE estado='pendiente'
                 AND fecha_creacion <= DATE_SUB(NOW(), INTERVAL 15 MINUTE)";

mysqli_query($conexion, $sqlCaducadas);

/* Cancelar una reserva seleccionada */
if(isset($_GET['cancelar'])){

    $id = $_GET['cancelar'];

    /* Cambiar el estado de la reserva a cancelada */
    $sqlCancelar = "UPDATE reserva
                    SET estado='cancelada'
                    WHERE id_reserva='$id'";

    mysqli_query($conexion, $sqlCancelar);

 /* Obtener datos de la reserva y del usuario para enviar la notificación */
    $sqlDatos = "SELECT usuario.nombre,
                 usuario.email,
                 pista.nombre AS pista,
                 reserva.fecha,
                 reserva.hora
                 FROM reserva
                 INNER JOIN usuario
                 ON reserva.id_usuario = usuario.id_usuario
                 INNER JOIN pista
                 ON reserva.id_pista = pista.id_pista
                 WHERE reserva.id_reserva='$id'";

    $resultadoDatos = mysqli_query($conexion, $sqlDatos);

    $datos = mysqli_fetch_assoc($resultadoDatos);

    /* Preparar el envío del correo electrónico */
    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';

        $mail->SMTPAuth = true;

        $mail->Username = 'fullcourtbooking@gmail.com';

        $mail->Password = 'soln ywnm mypb uwdz';

        $mail->SMTPSecure = 'tls';

        $mail->Port = 587;

        $mail->setFrom('fullcourtbooking@gmail.com', 'FullCourt');

        $mail->addAddress($datos['email']);

        $mail->isHTML(true);

        /* Crear el mensaje de cancelación para el usuario */
        $mail->Subject = 'Reserva cancelada';

        $mail->Body = "

        <h2>Reserva cancelada</h2>

        <p>Hola ".$datos['nombre'].", tu reserva ha sido cancelada.</p>

        <p><strong>Pista:</strong> ".$datos['pista']."</p>

        <p><strong>Fecha:</strong> ".$datos['fecha']."</p>

        <p><strong>Hora:</strong> ".$datos['hora']."</p>

        ";

        $mail->send();

           header("Location: admin_reservas.php");
exit();


    } catch (Exception $e) {
        header("Location: admin_reservas.php");
    exit();

    }
}

/* Obtener todas las reservas registradas */
$sql = "SELECT reserva.*, usuario.nombre AS usuario,
        pista.nombre AS pista
        FROM reserva
        INNER JOIN usuario
        ON reserva.id_usuario = usuario.id_usuario
        INNER JOIN pista
        ON reserva.id_pista = pista.id_pista
        ORDER BY fecha ASC";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Gestión de reservas | FullCourt</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css/style.css">

</head>

<body class="bg-light">

<!-- HEADER -->
<nav class="navbar navbar-expand-lg navbar-dark py-3 shadow" style="background:#14532d;">

<div class="container-fluid px-5">

<a class="navbar-brand d-flex align-items-center fw-bold fs-3" href="admin.php">

<img src="../icons/logo.png" alt="Logo" width="70" class="me-2">

FullCourt

</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="admin.php">
Panel
</a>
</li>

<li class="nav-item">
<a class="nav-link active fw-bold" href="admin_reservas.php">
Reservas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_incidencias.php">
Incidencias
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_pistas.php">
Pistas
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_usuarios.php">
Usuarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="admin_comentarios.php">
Comentarios
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="logout.php">
Cerrar sesión
</a>
</li>

</ul>

</div>

</div>

</nav>

<!-- CONTENIDO -->
<main class="py-5">

<div class="container">

<h1 class="text-center mb-3">
Gestión de reservas
</h1>

<p class="text-center text-muted mb-5">
Consulta, confirma y cancela reservas de los usuarios.
</p>

<div class="table-responsive">

<!-- TABLA DE RESERVAS -->
<table class="table table-bordered table-hover bg-white shadow">

<tr class="table-dark">

<th>Usuario</th>
<th>Pista</th>
<th>Fecha</th>
<th>Hora</th>
<th>Estado</th>
<th>Acciones</th>

</tr>

<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>
<?php echo $fila['usuario']; ?>
</td>

<td>
<?php echo $fila['pista']; ?>
</td>

<td>
<?php echo $fila['fecha']; ?>
</td>

<td>
<?php echo $fila['hora']; ?>
</td>

<td>

<?php

/* Mostrar el estado actual de la reserva */
if($fila['estado'] == "pendiente"){
    echo "<span class='badge bg-warning text-dark'>Pendiente</span>";
}elseif($fila['estado'] == "pagada"){
    echo "<span class='badge bg-success'>Pagada</span>";
}else{
    echo "<span class='badge bg-danger'>Cancelada</span>";
}
?>

</td>

<td>

<!-- Permitir cancelar únicamente reservas activas -->
<?php if($fila['estado'] != "cancelada"){ ?>

<a href="admin_reservas.php?cancelar=<?php echo $fila['id_reserva']; ?>"
class="btn btn-danger btn-sm"
onclick="confirmarCancelacion(event,this.href)">

Cancelar

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

</div>

<div class="text-center mt-4">

<a href="admin.php" class="btn btn-dark">

Volver al panel

</a>

</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-white pt-5 pb-3 mt-5" style="background:#14532d;">

<div class="container">

<div class="row g-5 align-items-start">

<div class="col-md-4 text-center text-md-start">

<h4 class="fw-bold mb-4">Contacto</h4>

<p>Av. Deportiva 123, Madrid</p>

<p>+34 614484308</p>

<p>fullcourtbooking.com</p>

</div>

<div class="col-md-4 text-center">

<h4 class="fw-bold mb-4">Horario</h4>

<p>L–V: 9:00 – 22:00</p>

<p>Sábados: 9:00 – 20:00</p>

<p>Domingos: Cerrado </p>

</div>

<div class="col-md-4 text-center text-md-end">

<h4 class="fw-bold mb-4">Ubicación</h4>

<iframe
src="https://www.google.com/maps?q=Av.%20Deportiva%20123,%20Madrid&output=embed">
</iframe>

</div>

</div>

<hr class="my-4">

<p class="text-center mb-0">
© 2026 FullCourt </p>

</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../js/script.js"></script>

</body>
</html>